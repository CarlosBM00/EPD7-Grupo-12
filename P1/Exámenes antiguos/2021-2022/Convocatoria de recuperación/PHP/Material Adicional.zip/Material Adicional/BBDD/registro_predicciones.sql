-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-06-2022 a las 15:37:23
-- Versión del servidor: 10.4.18-MariaDB
-- Versión de PHP: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `registro_predicciones`
--
CREATE DATABASE IF NOT EXISTS `registro_predicciones` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `registro_predicciones`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prediccion`
--

CREATE TABLE `prediccion` (
  `id` int(10) NOT NULL,
  `signo` varchar(255) NOT NULL,
  `fecha` date NOT NULL,
  `contenido` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `prediccion`
--

INSERT INTO `prediccion` (`id`, `signo`, `fecha`, `contenido`) VALUES
(1, 'Aries', '2022-06-04', 'Aries, te iría mucho mejor en el trabajo, si organizases más tus tareas, de esta forma tendrías más tiempo.\r\n\r\nAhora puedes conseguir un sueldo más elevado que el actual. Laboralmente, te está resultando todo bastante gratificante, tendrás satisfacciones. Tus parientes cercanos te harán sentir muy feliz, tendrás su compañía. Tendrás grandes alegrías y mucha complicidad con alguien, disfrútalo. Si quieres que todo vaya bien, tendrás que poner algo más de tu parte en el amor. Deberías descargarte de responsabilidades en todos los ámbitos de tu vida. Deberías hacerte una revisión médica para quedarte con tranquilidad y bien. Posiblemente tengas un día de descanso después de otro muy duro. Vas a tener muy buen humor y contagiarás energía positiva a los demás. Si dejas de pensar que te encuentras mal de salud, empezarás a sentirte mejor.'),
(2, 'Tauro', '2022-06-04', 'Ahora que te va bien económicamente, Tauro, no dejes de ahorrar, te vendrá bien. Te cuesta dar salida a tus ideas y que te hagan caso en el trabajo, lánzate. Mantente alerta, no estás para hacer gastos innecesarios en este momento. Hoy tendrás un buen día con tus compañeros, incluso te divertirás un poco. Harás las cosas que más te gustan y disfrutarás del espacio que necesitas. Los amigos van a ser tu apoyo en esta temporada y debes acudir a ellos. En el amor, profundizarás en alguna amistad, te sentirás con una unión especial a alguien. Tendrás ganas de relajarte y descansar, estás con bastante cansancio, hazlo. Tienes mucha energía y buen humor, trata de conservarlos algún tiempo. En la salud pon de tu parte, tu organismo no está respondiendo como quieres al estrés, procura descansar. De todas las formas, estás con las pilas puestas y no se te va a escapar nada de lo que ocurra.\r\n\r\n'),
(3, 'Geminis', '2022-06-05', 'Tendrás ganas de ir a trabajar ahora, Géminis, porque allí te sentirás muy cómodo. En el trabajo no te costará estar a la altura, lo harás todo muy bien. Tendrás cambios laborales que te desconcertarán un poco, pero te convienen. Profesionalmente, podrás lucirte y tendrás buena organización, te irá muy bien. Tu pareja será tu cómplice, te entenderá perfectamente en todo lo que hagas. En el amor, es buen momento para introducir cambios importantes en relación, lánzate. Hoy te apetecerá pasar una jornada tranquila en casa, junto con tu gente. No te olvidarás de tus seres queridos, vas a estar ahí para escucharlos. Estarás de buen humor y contagiarás tu alegría a los demás, que te seguirán. Estás con mucha energía, intuición y creatividad, saca partido del momento. Por tu salud, toma algunas precauciones, tienes una cierta propensión a resfriarte por el aire acondicionado.\r\n\r\n'),
(4, 'Cancer', '2022-06-03', 'Cáncer, pondrás esfuerzo y entusiasmo en el trabajo, y todo saldrá como quieres. Controla tus gastos, no te dejes llevar por los impulsos ni por lo que digan otros. Vas a tener la suerte de tu lado en asuntos de dinero, prueba a invertir. Podrías tener un encuentro especial con alguien del signo de Cáncer. Pon amor en todo lo que haces, tienes un buen momento para salir a pasear y relajarte, aprovéchalo. Tu relación con los nativos del signo Escorpio te dará muchas alegrías. Puede que vuelvas a ver a un amigo que llevaba un tiempo alejado de ti. Notarás una gran mejoría en cuanto a tu vitalidad y a tu estado de ánimo. Las tensiones que hayas podido tener estos días van a ir desapareciendo. En tu salud, si no te relajas, no se te pasarán esas molestias, no te agobies por nada.\r\n\r\n'),
(5, 'Virgo', '2022-06-08', 'Tendrás que estar menos pendiente en el trabajo.'),
(6, 'Virgo', '2022-06-04', 'Tendrás que estar más pendiente en el trabajo, Virgo, tendrás movimientos importantes. Tendrás buenas oportunidades para los negocios y las inversiones en general. Vas a disponer de una oportunidad magnífica para mejorar las cosas, debes aprovecharla. Tendrás noticias sobre algo interesante que vendrá de fuera, estate pendiente. Deberías poner orden en tus papeles o documentos, estás algo descuidado. Alguien de tu familia te dará buenos consejos, te interesa prestarle atención. En el amor, podrás resolver alguna que otra desavenencia que has tenido últimamente con tu pareja. Vas a tener renovadas tus energías, estarás muy bien. No tendrás grandes problemas de salud, pero aun así, no dejes de cuidarte, es muy importante. Te conviene cambiar un poco tu estilo de vida sedentario, no te beneficia. Te conviene hacer alguna modificación importante para mejorar tu calidad de vida.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `email` varchar(255) NOT NULL,
  `contrasenia_hash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`email`, `contrasenia_hash`) VALUES
('root@entidad.com', '$2y$10$oeOnQ/5loEbJJh1N/4DvlumSRpimSeB0UCTIdS.KbXBjvCh536/sK');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `prediccion`
--
ALTER TABLE `prediccion`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `prediccion`
--
ALTER TABLE `prediccion`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
