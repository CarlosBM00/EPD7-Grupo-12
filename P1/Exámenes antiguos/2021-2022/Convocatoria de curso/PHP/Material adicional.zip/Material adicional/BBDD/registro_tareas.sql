-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:33065
-- Tiempo de generación: 17-12-2021 a las 09:14:54
-- Versión del servidor: 10.4.17-MariaDB
-- Versión de PHP: 7.3.26

--
-- Base de datos: `registro_tareas`
--

CREATE DATABASE IF NOT EXISTS `registro_tareas` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE `registro_tareas`;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarea`
--

CREATE TABLE `tarea` (
  `id` int(10) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `fecha_ini` date NOT NULL,
  `fecha_fin` date DEFAULT NULL,
  `duracion_dias` int(10) DEFAULT NULL,
  `prioridad` varchar(255) NOT NULL,
  `estado` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tarea`
--

INSERT INTO `tarea` (`id`, `nombre`, `fecha_ini`, `fecha_fin`, `duracion_dias`, `prioridad`, `estado`) VALUES
(5, 'Logs de errores', '2022-01-01', '0000-00-00', 0, 'ALTA', 'EN EJECUCIÓN'),
(7, 'Limpieza', '2021-12-01', '2021-12-15', 14, 'MEDIA', 'PROCESADA'),
(18, 'Carga masiva', '2021-01-01', '0000-00-00', 0, 'MEDIA', 'ESPERANDO EJECUCIÓN'),
(19, 'Carga nocturna', '2021-02-01', '2021-02-03', 2, 'MEDIA', 'PROCESADA'),
(20, 'Logs de servidores', '2021-12-15', '2021-12-16', 1, 'BAJA', 'ESPERANDO EJECUCIÓN');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `email` varchar(255) NOT NULL,
  `contrasenia_hash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`email`, `contrasenia_hash`) VALUES
('root@entidad.com', '$2y$10$bgFMIPuP10XhQpccOyGf9O5R.rYOqdSBVhOZbfXDQtq0O4GIyUezi');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tarea`
--
ALTER TABLE `tarea`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tarea`
--
ALTER TABLE `tarea`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;
